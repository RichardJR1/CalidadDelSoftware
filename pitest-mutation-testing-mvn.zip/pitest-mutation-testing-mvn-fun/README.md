### Build 
```bash
./mvnw clean install 
```
